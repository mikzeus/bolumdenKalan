import java.util.Scanner;

public class ucakBileti {
    public static void main(String[] args) {

        int km, yas, biletTipi;
        double biletFiyatı;

        Scanner inp= new Scanner(System.in);

        System.out.println("lütfen uçuş mesafesini km cinsinden giriniz:");
        km= inp.nextInt();

        System.out.println("lütfen yaşınızı giriniz:");
        yas = inp.nextInt();

        System.out.println("lütfen bilet tipi seçiniz: (tekYon =>1, gidisDonus =>2):");
        biletTipi= inp.nextInt();

        biletFiyatı= km*0.10;

        if (biletTipi==1 || biletTipi==2){
            if(biletTipi==1){
                biletFiyatı=biletFiyatı/2;
            }
        }




    }
}
