import java.util.Scanner;

public class faktoriyelHesap {
    public static void main(String[] args) {

      Scanner input= new Scanner(System.in);

      double sayi,faktoriyel=1;

      System.out.println("lütfen bir sayı giriniz:");
        sayi=input.nextDouble();

      while (sayi>=1){
          faktoriyel=faktoriyel*sayi;
          System.out.println("Faktoriyel:" +" " +faktoriyel +" " +"sayı:"+" " + sayi );
         sayi--;

      }
        System.out.println("sonuc:"+faktoriyel);
    }
}
