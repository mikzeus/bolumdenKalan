public class donguWhile {
    public static void main(String[] args) {
        int i=0;
        while(i<=5){
            System.out.println("Java");
            i++;
        }
        System.out.println("Dongu bitti:" + i);

    }
}
